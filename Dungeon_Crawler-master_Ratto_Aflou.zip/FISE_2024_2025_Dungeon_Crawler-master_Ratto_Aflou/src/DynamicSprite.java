import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.util.ArrayList;

public class DynamicSprite extends SolidSprite{
    private Direction direction = Direction.EAST;
    private double speed = 8;
    private double timeBetweenFrame = 250;
    private boolean isWalking =true;
    private int health;
    private int maxHealth;
    private boolean isDead;
    private Image gameOverImage = Toolkit.getDefaultToolkit().getImage("./img/GAMEOVER.png");

    public DynamicSprite(double x, double y, Image image, double width, double height, int maxHealth) {
        super(x, y, image, width, height);
        this.health = maxHealth;
        this.isDead = false;
        this.maxHealth = maxHealth;
    }

    public int getHealth() {
        return health;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void takeDamage(int damage) {
        health = Math.max(0, health - damage);

        if (health <= 0 && !isDead) {
            isDead = true;
        }
    }


    public boolean isDead() {
        return isDead;
    }



    public void Heal(int amount) {
        health = Math.min(maxHealth, health + amount);
    }

    private boolean isMovingPossible(ArrayList<Sprite> environment){
        Rectangle2D.Double moved = new Rectangle2D.Double();
        switch(direction){
            case EAST: moved.setRect(super.getHitBox().getX()+speed,super.getHitBox().getY(),
                                    super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case WEST:  moved.setRect(super.getHitBox().getX()-speed,super.getHitBox().getY(),
                    super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case NORTH:  moved.setRect(super.getHitBox().getX(),super.getHitBox().getY()-speed,
                    super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case SOUTH:  moved.setRect(super.getHitBox().getX(),super.getHitBox().getY()+speed,
                    super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
        }


        for (Sprite s : environment){

            if((s instanceof Trap) && (s!=this)){
                if (((Trap) s).intersect(moved)){
                    if (((Trap) s).isActive()){
                        this.takeDamage(((Trap) s).getDamage());
                        ((Trap) s ).deactivate();
                    }
                    return true;
                }
            }
            if ((s instanceof SolidSprite) && (s!=this)){
                if (((SolidSprite) s).intersect(moved)){
                    return false;
                }
            }
        }
        return true;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    private void move(){
        switch (direction){
            case NORTH -> {
                this.y-=speed;
            }
            case SOUTH -> {
                this.y+=speed;
            }
            case EAST -> {
                this.x+=speed;
            }
            case WEST -> {
                this.x-=speed;
            }
        }
    }

    public void moveIfPossible(ArrayList<Sprite> environment){
        if (isMovingPossible(environment)){
            move();
        }
    }
    private void drawHealthBar(Graphics g) {
        int barWidth = 40;
        int barHeight = 5;
        int x = (int) this.x + (int)(64 / 2) - (barWidth / 2);
        int y = (int) this.y - 10;


        g.setColor(Color.BLACK);
        g.fillRect(x, y, barWidth, barHeight);

        g.setColor(Color.GREEN);
        int currentBarWidth = (int)((health / (double) maxHealth) * barWidth);
        g.fillRect(x, y, currentBarWidth, barHeight);


    }

    @Override
    public void draw(Graphics g) {

        if (health <= 0){
            g.drawImage(gameOverImage,0,0,1000,600, null);
        }
        if (health > 0) {
            int spriteSheetNumberOfColumn = 10;
            int index = (int) (System.currentTimeMillis() / timeBetweenFrame % spriteSheetNumberOfColumn);


            int spriteX = (int) (index * this.width);
            int spriteY = (int) (direction.getFrameLineNumber() * this.height);


            g.drawImage(
                    image,
                    (int) x, (int) y,
                    (int) (x + width), (int) (y + height),
                    spriteX, spriteY,
                    spriteX + (int) width, spriteY + (int) height,
                    null
            );

            drawHealthBar(g);
        }

    }




}
