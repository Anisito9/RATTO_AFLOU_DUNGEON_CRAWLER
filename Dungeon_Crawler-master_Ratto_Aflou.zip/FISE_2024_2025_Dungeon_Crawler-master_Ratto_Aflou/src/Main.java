import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Main {

    JFrame displayZoneFrame;

    RenderEngine renderEngine;
    GameEngine gameEngine;
    PhysicEngine physicEngine;


    public static void main(String[] args) throws Exception {

        JFrame welcomeFrame = new JFrame("Écran d'accueil");
        MainMenu mainMenu = new MainMenu();
        welcomeFrame.add(mainMenu);
        welcomeFrame.setSize(1000, 600); // Taille de la fenêtre
        welcomeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        welcomeFrame.setVisible(true);
        mainMenu.requestFocusInWindow();
    }

    public Main() throws Exception{
        displayZoneFrame = new JFrame("Java Labs");
        displayZoneFrame.setSize(1000,600);
        displayZoneFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);

        DynamicSprite hero = new DynamicSprite(100,100,
                ImageIO.read(new File("./img/heroTileSheetLowRes.png")),48,50, 50);

        renderEngine = new RenderEngine(displayZoneFrame);
        physicEngine = new PhysicEngine();
        gameEngine = new GameEngine(hero,displayZoneFrame);

        Timer renderTimer = new Timer(50,(time)-> renderEngine.update());
        Timer gameTimer = new Timer(50,(time)-> gameEngine.update());
        Timer physicTimer = new Timer(50,(time)-> physicEngine.update());

        renderTimer.start();
        gameTimer.start();
        physicTimer.start();
        physicEngine.setMainCharacter(hero);

        displayZoneFrame.getContentPane().add(renderEngine);
        displayZoneFrame.setVisible(true);

        Playground level = new Playground("./data/level1.txt");
        //SolidSprite testSprite = new DynamicSprite(100,100,test,0,0);
        renderEngine.addToRenderList(level.getSpriteList());
        renderEngine.addToRenderList(hero);
        physicEngine.addToMovingSpriteList(hero);
        physicEngine.setEnvironment(level.getSolidSpriteList());

        displayZoneFrame.addKeyListener(gameEngine);
    }
    public static void returnToMainMenu(JFrame currentFrame) {
        if (currentFrame != null) {
            currentFrame.dispose(); // Ferme la fenêtre actuelle
        }
        JFrame welcomeFrame = new JFrame("Écran d'accueil");
        MainMenu mainMenu = new MainMenu();
        welcomeFrame.add(mainMenu);
        welcomeFrame.setSize(1000, 600); // Taille de la fenêtre
        welcomeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        welcomeFrame.setVisible(true);
        mainMenu.requestFocusInWindow(); 



    }


}



