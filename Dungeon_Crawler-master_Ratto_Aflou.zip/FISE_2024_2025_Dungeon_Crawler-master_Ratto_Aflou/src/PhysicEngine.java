import java.lang.reflect.Array;
import java.util.ArrayList;

public class PhysicEngine implements Engine {
    private ArrayList<DynamicSprite> movingSpriteList;
    private ArrayList<Sprite> environment;
    private DynamicSprite mainCharacter;

    public PhysicEngine() {
        movingSpriteList = new ArrayList<>();
        environment = new ArrayList<>();
    }

    public void addToEnvironmentList(Sprite sprite) {
        if (!environment.contains(sprite)) {
            environment.add(sprite);
        }
    }

    public void setEnvironment(ArrayList<Sprite> environment) {

        this.environment = environment;
    }

    public ArrayList<DynamicSprite> getMovingSpriteList() {
        return movingSpriteList;
    }

    public void addToMovingSpriteList(DynamicSprite sprite) {
        if (!movingSpriteList.contains(sprite)) {
            movingSpriteList.add(sprite);
        }
    }

    public void setMainCharacter(DynamicSprite mainCharacter) {
        this.mainCharacter = mainCharacter;
        addToMovingSpriteList(mainCharacter);
    }

    @Override
    public void update() {
        for (DynamicSprite dynamicSprite : movingSpriteList) {
            dynamicSprite.moveIfPossible(environment);

        }
    }

}
